

window.onload = async () => {
    const res = await fetch("https://jsonplaceholder.typicode.com/todos");
    const todos = await res.json();
    for (let i = 0;  i < todos.length; i++) {
      showData(todos[i]);
    }
  };

  
   function showData(todo) {
    const row = document.createElement("tr");
    row.id = `row-${todo.id}`;
    row.innerHTML = `
    <td>${todo.userId}</td>
      <td>${todo.id}</td>
      <td>${todo.title}</td>
      <td>${todo.completed ? "True" : "False"}</td>
      <td class="actions">
        <button class="edit-btn" onclick="Update(${todo.id}, ${todo.userId}, '${todo.title}', ${todo.completed})">Edit</button>
        <button class="delete-btn" onclick="Delete(${todo.id})">Delete</button>
      </td>
    `;
    todoTable.appendChild(row);
  }


    async function saveData(e) {
    e.preventDefault();
 
 
    const userId = document.getElementById("userId").value;
    const title = document.getElementById("title").value;
    const completed = document.getElementById("completed").checked;
    const objId = document.getElementById("objId").value;
   
    const todoData = {
      userId: Number(userId),
      title,
      completed
    };

    if (objId) {

        const res = await fetch(`https://jsonplaceholder.typicode.com/todos/${objId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...todoData, id: Number(objId) })
      });
      const updatedTodo = await res.json();
      document.getElementById(`row-${objId}`).remove();
      showData(updatedTodo);
    } else {

        const res = await fetch("https://jsonplaceholder.typicode.com/todos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(todoData)
      });
      const newTodo = await res.json();
      showData(newTodo);
    }

    document.getElementById("formId").reset();
    document.getElementById("objId").value = "";
  }



   function Update(id, userId, title, completed) {
    document.getElementById("userId").value = userId;
    document.getElementById("title").value = title;
    document.getElementById("completed").checked = completed;
    document.getElementById("objId").value = id;
  }



 async function Delete(id) {

      await fetch(`https://jsonplaceholder.typicode.com/todos/${id}`, {
      method: "DELETE"
    });
    document.getElementById(`row-${id}`).remove();
  }